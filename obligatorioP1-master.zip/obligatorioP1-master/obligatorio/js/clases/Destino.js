class Destinos {
    constructor(id,nombre,precio,img,estado,cuposDisponibles,descripcion,esOferta) {
        this.id=id
        this.nombreDestino=nombre
        this.precio=precio
        this.imagen=img
        this.estado=estado
        this.cuposDisponibles=cuposDisponibles
        this.descripcion=descripcion
        this.esOferta=esOferta
    }
}